"""
db.py — Database connection and query execution for the Warehouse
Closure Analysis app.

This is the one file that should ever need to change if you move
databases, change credentials, or switch to environment variables
for secrets.
"""
import pandas as pd
import mysql.connector as mconn
import streamlit as st


@st.cache_resource
def init_connection():
    """Create (and cache) a single MySQL connection for the app's
    lifetime. @st.cache_resource means this only actually runs once
    per session, not on every rerun."""
    return mconn.connect(
        host='localhost',
        user='root',
        password='password',
        database='mintclassics',
        auth_plugin='mysql_native_password'
    )


def get_connection():
    """Public entry point other modules should use to get a live
    connection, with a friendly Streamlit error + stop on failure."""
    try:
        return init_connection()
    except Exception as e:
        st.error(f"Could not connect to MYSQL Server: {e}")
        st.stop()


def run_query(query):
    """Execute a SQL string against the app's MySQL connection and
    return the result as a DataFrame."""
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute(query)
        columns = [desc[0] for desc in cur.description]
        result = cur.fetchall()
        return pd.DataFrame(result, columns=columns)
    finally:
        cur.close()
