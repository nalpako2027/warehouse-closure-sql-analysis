# To run the app, run this on terminal: /opt/anaconda3/bin/streamlit run /Users/orhankaplan/PROJECTS/Github_Projects/Mint_Classic_SQL/app.py
import streamlit as st

from db import run_query
from queries import QUESTIONS, FINAL_SCORES_QUERY
from charts import (
    WAREHOUSE_ORDER,
    format_value,
    make_bullet_chart,
    make_treemap,
    make_composite_score_chart,
)

# ─────────────────────────────────────────────────────────────
# Page configuration
# ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title='Warehouse Closure Analysis Framework',
    layout='wide',
    initial_sidebar_state='expanded'
)

# ─────────────────────────────────────────────────────────────
# Page-only styling constants (not needed anywhere else, so they
# stay local to this file rather than living in charts.py)
# ─────────────────────────────────────────────────────────────
NAVY_PRIMARY   = "#14213D"
NAVY_DARK      = "#0B1526"
NAVY_ACCENT    = "#F4A261"   # unselected level buttons — orange
NAVY_SELECTED  = "#BFFF00"   # selected level button — lime
GOLD_HIGHLIGHT = "#E9C46A"   # Final Recommendation button — always gold
LIGHT_TEXT     = "#F5F7FA"

# ─────────────────────────────────────────────────────────────
# Custom CSS — navy sidebar, button-style navigation
# ─────────────────────────────────────────────────────────────
st.markdown(f"""
    <style>
    section[data-testid="stSidebar"] {{
        background-color: {NAVY_PRIMARY};
    }}
    section[data-testid="stSidebar"] * {{
        color: {LIGHT_TEXT} !important;
    }}
    section[data-testid="stSidebar"] h1, section[data-testid="stSidebar"] h2 {{
        color: white !important;
        font-weight: 700;
    }}

    /* Sidebar nav buttons — default (unselected), orange */
    section[data-testid="stSidebar"] button[kind="secondary"] {{
        background-color: {NAVY_ACCENT};
        color: {NAVY_DARK} !important;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        margin-bottom: 4px;
    }}
    section[data-testid="stSidebar"] button[kind="secondary"]:hover {{
        background-color: #E08E4C;
        color: {NAVY_DARK} !important;
    }}

    /* Sidebar nav buttons — selected level, lime */
    section[data-testid="stSidebar"] button[kind="primary"] {{
        background-color: {NAVY_SELECTED};
        color: {NAVY_DARK} !important;
        border: none;
        border-radius: 8px;
        font-weight: 700;
        margin-bottom: 4px;
    }}
    section[data-testid="stSidebar"] button[kind="primary"]:hover {{
        background-color: #A8E000;
        color: {NAVY_DARK} !important;
    }}

    /* Final Recommendation button — always the last button in the
       sidebar, styled gold regardless of selection state so it
       reads as a distinct call-to-action, not just another level. */
    section[data-testid="stSidebar"] div[data-testid="stButton"]:last-of-type button {{
        background-color: {GOLD_HIGHLIGHT} !important;
        color: {NAVY_DARK} !important;
        font-weight: 700 !important;
        border: none !important;
    }}
    section[data-testid="stSidebar"] div[data-testid="stButton"]:last-of-type button:hover {{
        background-color: #F0D189 !important;
    }}

    /* Main-panel question buttons */
    div[data-testid="stButton"] button[kind="secondary"] {{
        border-radius: 8px;
    }}
    div[data-testid="stButton"] button[kind="primary"] {{
        background-color: {NAVY_PRIMARY};
        border-radius: 8px;
    }}

    h1 {{ color: {NAVY_PRIMARY}; }}
    div[data-testid="stMetric"] {{
        background-color: #F4F6FA;
        border: 1px solid #DCE2ED;
        border-radius: 10px;
        padding: 12px 16px;
    }}
    h2, h3 {{
        border-bottom: 2px solid {NAVY_PRIMARY};
        padding-bottom: 4px;
    }}
    .conclusion-box textarea {{
        background-color: #F4F6FA;
        border: 1px solid #DCE2ED;
    }}
    </style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────
# Header
# ─────────────────────────────────────────────────────────────
st.title("🏭 Warehouse Closure Analysis")
st.caption("A SQL-Based Multi-Criteria Decision Framework")


def render_question(question_label, config):
    st.subheader(question_label)

    df = run_query(config["query"])
    y_col = config["y_col"]
    y_label = config["y_label"]
    fmt = config["fmt"]
    chart_type = config["chart_type"]

    # KPI row
    df_sorted = df.sort_values(y_col, ascending=False)
    top_row = df_sorted.iloc[0]
    bottom_row = df_sorted.iloc[-1]
    kpi1, kpi2, kpi3 = st.columns(3)
    kpi1.metric(f"Highest — {top_row['warehouseName']}", format_value(top_row[y_col], fmt))
    kpi2.metric(f"Lowest — {bottom_row['warehouseName']}", format_value(bottom_row[y_col], fmt))
    kpi3.metric("Average", format_value(df[y_col].mean(), fmt))

    col1, col2 = st.columns([1.4, 1])

    with col1:
        st.markdown(f"**{y_label} by Warehouse**")
        if chart_type == "bullet":
            st.altair_chart(make_bullet_chart(df, y_col, y_label, fmt), use_container_width=True)
        elif chart_type == "treemap":
            st.plotly_chart(make_treemap(df, y_col, y_label), use_container_width=True)

    with col2:
        st.markdown("**Conclusion**")
        st.text_area(
            label="Conclusion",
            value=config["conclusion"],
            height=280,
            key=f"conclusion_{question_label}",
            label_visibility="collapsed",
        )

# ─────────────────────────────────────────────────────────────
# Sidebar navigation — buttons instead of radio/selectbox
# ─────────────────────────────────────────────────────────────
if "selected_level" not in st.session_state:
    st.session_state.selected_level = "Level 1"

st.sidebar.title("Navigation")

for lvl in ["Level 1", "Level 2", "Level 3", "Level 4"]:
    btn_type = "primary" if st.session_state.selected_level == lvl else "secondary"
    if st.sidebar.button(lvl, key=f"nav_{lvl}", type=btn_type, use_container_width=True):
        st.session_state.selected_level = lvl

st.sidebar.markdown("---")

final_type = "primary" if st.session_state.selected_level == "Level 5: Final Recommendation" else "secondary"
if st.sidebar.button("🏆 Final Recommendation", key="nav_final", type=final_type, use_container_width=True):
    st.session_state.selected_level = "Level 5: Final Recommendation"

level = st.session_state.selected_level

# ─────────────────────────────────────────────────────────────
# LEVELS 1–4 — driven by the QUESTIONS registry
# ─────────────────────────────────────────────────────────────
LEVEL_ICONS = {"Level 1": "📊", "Level 2": "📦", "Level 3": "🤝", "Level 4": "🔁"}
LEVEL_TITLES = {
    "Level 1": "Current State Assessment",
    "Level 2": "Product Analysis",
    "Level 3": "Customer Impact",
    "Level 4": "Consolidation Feasibility",
}

if level in QUESTIONS:
    st.header(f"{LEVEL_ICONS[level]} {level}: {LEVEL_TITLES[level]}")

    if QUESTIONS[level]:
        question_keys = list(QUESTIONS[level].keys())
        state_key = f"selected_question_{level}"
        if state_key not in st.session_state:
            st.session_state[state_key] = question_keys[0]

        q_cols = st.columns(len(question_keys))
        for i, q_label in enumerate(question_keys):
            q_type = "primary" if st.session_state[state_key] == q_label else "secondary"
            if q_cols[i].button(q_label, key=f"qbtn_{level}_{q_label}", type=q_type, use_container_width=True):
                st.session_state[state_key] = q_label

        st.markdown("---")
        selected_question = st.session_state[state_key]
        config = QUESTIONS[level][selected_question]
        render_question(selected_question, config)
    else:
        st.info(f"No questions wired up yet for {level}. Add entries to the QUESTIONS dict in queries.py following the Level 1 pattern.")

# ─────────────────────────────────────────────────────────────
# LEVEL 5 — Final weighted recommendation with interactive sliders
# ─────────────────────────────────────────────────────────────
elif level == "Level 5: Final Recommendation":
    st.header("🏆 Level 5: Final Weighted Recommendation")
    st.caption("Adjust the level weights below to see how the closure ranking responds.")

    scores_df = run_query(FINAL_SCORES_QUERY)

    st.markdown("##### Level Weights")
    w1, w2, w3, w4 = st.columns(4)
    with w1:
        weight_l1 = st.slider("Level 1", 0.0, 1.0, 0.15, 0.05)
    with w2:
        weight_l2 = st.slider("Level 2", 0.0, 1.0, 0.35, 0.05)
    with w3:
        weight_l3 = st.slider("Level 3", 0.0, 1.0, 0.30, 0.05)
    with w4:
        weight_l4 = st.slider("Level 4", 0.0, 1.0, 0.20, 0.05)

    total_weight = weight_l1 + weight_l2 + weight_l3 + weight_l4
    if abs(total_weight - 1.0) > 0.001:
        st.warning(f"Weights currently sum to {total_weight:.2f} — normalizing to 1.0 for the score below.")

    scores_df['final_score'] = (
        scores_df['level1_score'] * weight_l1 +
        scores_df['level2_score'] * weight_l2 +
        scores_df['level3_score'] * weight_l3 +
        scores_df['level4_score'] * weight_l4
    ) / total_weight

    ranked_df = scores_df.sort_values('final_score', ascending=False).reset_index(drop=True)

    col1, col2 = st.columns([1.4, 1])
    with col1:
        st.markdown("**Composite Score by Warehouse**")
        st.altair_chart(make_composite_score_chart(ranked_df), use_container_width=True)

    with col2:
        st.markdown("**Conclusion**")
        top_candidate = ranked_df.iloc[0]
        default_conclusion = f"Under these weights, {top_candidate['warehouseName']} ranks highest as the closure candidate (score: {top_candidate['final_score']:.3f})."
        st.text_area(
            label="Conclusion",
            value=default_conclusion,
            height=280,
            key="conclusion_final",
            label_visibility="collapsed",
        )
