"""
queries.py — SQL and question metadata for the Warehouse Closure
Analysis app.

To add a new question to an existing level: add one entry to the
relevant dict below with a query, a y-axis column, a chart_type,
and a starting conclusion sentence. app.py reads this registry to
build both the sidebar buttons and the rendered chart/KPIs, so you
never need to touch app.py to add a question — only this file and,
if it's a new chart shape, charts.py.
"""

QUESTIONS = {
    "Level 1": {
        "Q1: Capacity Utilization": {
            "query": """
                SELECT
                    warehouseName,
                    CAST(REPLACE(warehousePctCap, '%', '') AS SIGNED) as warehousePctCap
                FROM warehouses
                WHERE warehouseCode IS NOT NULL
                ORDER BY warehousePctCap DESC;
            """,
            "y_col": "warehousePctCap",
            "y_label": "Capacity Utilization (%)",
            "fmt": "%",
            "chart_type": "bullet",
            "conclusion": "Add your interpretation of the capacity utilization results here.",
        },
        "Q2: Total Inventory Value": {
            "query": """
                SELECT w.warehouseCode, w.warehouseName,
                       SUM(quantityInStock*buyPrice) AS total_inventory_value
                FROM warehouses w
                JOIN products p ON w.warehouseCode = p.warehouseCode
                GROUP BY w.warehouseCode, w.warehouseName
                ORDER BY total_inventory_value DESC;
            """,
            "y_col": "total_inventory_value",
            "y_label": "Total Inventory Value ($)",
            "fmt": "$",
            "chart_type": "treemap",
            "conclusion": "Add your interpretation of the inventory value results here.",
        },
    },
    "Level 2": {},
    "Level 3": {},
    "Level 4": {},
}

# Level 5 pulls from a pre-computed scores table rather than the
# QUESTIONS registry, since it's a composite across all levels.
FINAL_SCORES_QUERY = "SELECT * FROM warehouse_scores;"
