"""
charts.py — Color palette, formatting, and chart builders for the
Warehouse Closure Analysis app.

WAREHOUSE_COLORS is the single source of truth for warehouse colors
so a given warehouse is always the same color in every chart. Add a
new chart_type here (and reference it from queries.py's per-question
config) whenever a new question needs a different visualization.
"""
import altair as alt
import plotly.express as px

WAREHOUSE_COLORS = {
    "North": "#264653",   # dark slate teal
    "South": "#2A9D8F",   # teal
    "East":  "#E9C46A",   # gold
    "West":  "#E76F51",   # burnt orange
}
WAREHOUSE_ORDER = list(WAREHOUSE_COLORS.keys())

NAVY_DARK = "#0B1526"


def format_value(value, fmt):
    if fmt == "%":
        return f"{value:.1f}%"
    if fmt == "$":
        return f"${value:,.0f}"
    return f"{value:.2f}"


def make_bullet_chart(df, y_col, y_label, fmt):
    """Horizontal bullet chart: light track = full range, colored
    bar = actual value, dark tick = the cross-warehouse average
    as a reference point."""
    max_domain = 100 if fmt == "%" else df[y_col].max() * 1.15

    track_df = df.copy()
    track_df["_track"] = max_domain
    track = alt.Chart(track_df).mark_bar(color="#E2E6EF", size=26).encode(
        y=alt.Y("warehouseName:N", sort=WAREHOUSE_ORDER, title=None),
        x=alt.X("_track:Q", title=y_label, scale=alt.Scale(domain=[0, max_domain])),
    )

    measure = alt.Chart(df).mark_bar(size=11).encode(
        y=alt.Y("warehouseName:N", sort=WAREHOUSE_ORDER),
        x=alt.X(f"{y_col}:Q"),
        color=alt.Color(
            "warehouseName:N",
            scale=alt.Scale(domain=WAREHOUSE_ORDER, range=[WAREHOUSE_COLORS[w] for w in WAREHOUSE_ORDER]),
            legend=None,
        ),
        tooltip=["warehouseName", y_col],
    )

    avg_val = df[y_col].mean()
    avg_df = df[["warehouseName"]].copy()
    avg_df["_avg"] = avg_val
    avg_tick = alt.Chart(avg_df).mark_tick(color=NAVY_DARK, thickness=3, size=26).encode(
        y=alt.Y("warehouseName:N", sort=WAREHOUSE_ORDER),
        x=alt.X("_avg:Q"),
        tooltip=[alt.Tooltip("_avg:Q", title="Average", format=".1f")],
    )

    return (track + measure + avg_tick).properties(height=260)


def make_treemap(df, y_col, y_label):
    fig = px.treemap(
        df,
        path=["warehouseName"],
        values=y_col,
        color="warehouseName",
        color_discrete_map=WAREHOUSE_COLORS,
    )
    fig.update_traces(
        texttemplate="<b>%{label}</b><br>$%{value:,.0f}",
        textfont_size=16,
    )
    fig.update_layout(margin=dict(t=10, l=10, r=10, b=10), height=380)
    return fig


def make_composite_score_chart(ranked_df):
    """Level 5 bar chart of final weighted composite score per warehouse."""
    return (
        alt.Chart(ranked_df)
        .mark_bar()
        .encode(
            x=alt.X("warehouseName:N", sort=WAREHOUSE_ORDER, title="Warehouse"),
            y=alt.Y("final_score:Q", title="Composite Score"),
            color=alt.Color(
                "warehouseName:N",
                scale=alt.Scale(domain=WAREHOUSE_ORDER, range=[WAREHOUSE_COLORS[w] for w in WAREHOUSE_ORDER]),
                legend=None,
            ),
            tooltip=["warehouseName", "final_score"],
        )
        .properties(height=380)
    )
